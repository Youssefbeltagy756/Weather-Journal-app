# Weather Journal App (Udacity Project)

This Weather Journal App is an app that takes data from and external API and sends specific data to the server. Data is taken again from the server and displayed in the UI to the user.

## Installation

install node.js and run server.js from the command prompt.
Then, open localhost:8080 from your browser


## Usage
This project can be used by users to get the weather data in any place in the world by just typing in the zip code.

## Author
Youssef Yosry Mohamed