
/*First we get the input, text area and thegenerate buttons by ids*/
let GenerateBtn = document.getElementById('generate');
let ZipCode = document.getElementById('zip');
let Feeling = document.getElementById('feelings');
let EntryHolder = document.getElementById('entryHolder');
let ClassArray = document.getElementsByClassName('ClassArray');
let ErrorSpan = document.getElementsByClassName('error');

/*Get Today's Date*/
var d = new Date();
let Days = ["Sunday","Monday","Tuesday","wednesday","Thursday","Friday","Saturday"];

/*Base URL and API key*/
const Key = "&appid=2b350095680dae2479ed809b29097f0c";
const BaseURL = "https://api.openweathermap.org/data/2.5/weather?zip=";

/*Async function that is resposnble to get the data from the API and assign the data 
needed from it into variables*/
async function getData()
    {
        /*In Project Rubric, The Project data must be an object so I will define "Data" as an object in the code
        sinppet below*/
        const Response = await fetch(BaseURL+ZipCode.value+Key)
        /*In case the user enters valid aid code the Response is fetched and data retrieved*/
        .then (async(Response) =>{
            const APIData = await Response.json();
            const Data = {
            CityName: APIData.name,
            Temperature: parseInt(APIData.main.feels_like-275.15),
            WeatherDescription: APIData.weather[0].description,
            Date: Days[d.getDay()]+" "+(d.getMonth()+1)+" "+d.getFullYear(),
            Content: Feeling.value
            }
            /*Use post data and passing url and "Data" object as parameters to be sent to the server*/
            postData('/addNewData',Data).then(UpdateUI());
        }).catch(error => {
          /*In case User enters invalid data*/
          console.log("error",error)
          ErrorSpan[0].style.display = 'grid';
        });
        
    }
 
/*Make The Post Request from the client side to the server client*/
const postData = async (url='', Data = {})=>{
    console.log(Data);
      const response= await fetch(url, {
      method: 'POST', 
      credentials: 'same-origin',
      headers: {
          'Content-Type': 'application/json',
      },
      /*Convert Data to JSON*/    
      body: JSON.stringify(Data), 
    });

      try {
        const newData = await response.json();
        return newData;
      }catch(error) {
      console.log("error", error);
      }
  }
  /*Getting div elements using get Element by id*/
  let FirstDiv = document.getElementById('name');
  let SecondDiv = document.getElementById('temp');
  let ThirdDiv = document.getElementById('desc');
  let FourthDiv = document.getElementById('date');
  let FifthDiv = document.getElementById('content');
  const UpdateUI = async () =>
  {
      /*Use fetch funvtion to reach the endpoint created in the server Asynchronously*/
      const response = await fetch('/allData');
      const DataAll = await response.json();
      /*I Used an If Condition beacuse the User must enter any string in the Feelings text area*/
      if (DataAll.Content !=='')
      {
        /*Setting the properties of existing HTML elements from the DOM*/
        EntryHolder.style.visibility = 'visible';
        FirstDiv.style.fontSize = '100%';
        SecondDiv.style.fontSize = '200%';
        ThirdDiv.style.fontSize = '50%';
        FourthDiv.style.fontSize = '90%';
        FifthDiv.style.fontSize = '100%'

        /*Display the Data taken from the server using INNERHTML and updating UI dynamiclly
        The Rubric required only few data, but I just added more*/
        ClassArray[0].innerHTML = DataAll.CityName;
        ClassArray[1].innerHTML = DataAll.Temperature+"°C";
        ClassArray[2].innerHTML = DataAll.WeatherDescription;
        ClassArray[3].innerHTML = DataAll.Date;
        ClassArray[4].innerHTML = DataAll.Content;
      }else
      {
        /*If The user didn't enter a response in the textarea, an error 
        span message is displayed*/
        ErrorSpan[1].style.display = 'grid';
      }
    }
  


/*Add Event Listener to the generate Button*/
GenerateBtn.addEventListener('click',()=>
{
    /*For each time the user clicks on generate button,
    The error messages must be removed*/
    ErrorSpan[0].style.display = 'none';
    ErrorSpan[1].style.display = 'none';

    getData();
})






