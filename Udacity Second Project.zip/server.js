/*To make the POST request and take the data from the client-side to/addNewData*/
let projectData = {}

/*Require express to build our server that manages the routing between the server-side and 
client-side javascript*/
const express = require('express');

/*Then we create instance of our app*/
const app = express();

/*Require our dependancies(body parser)*/
const BodyParser = require('body-parser');

/*get our middlewares and use the "use function"*/
app.use(BodyParser.urlencoded( {extended: false}));
app.use(BodyParser.json());

/*To support cross origin resource sharing*/
const cors = require('cors');
const { request, response } = require('express');

/*create an instance*/
app.use(cors());

/*I have created a file named"website in the same level of the server.js file so
to let the server.js reaches our index.html we will use express.static"*/
app.use(express.static('website'));

/*Now to run our server we have to use the .listen method and use console.log to see
our port number and make sure it is running*/
const port = 8080;

const server = app.listen(port,listeningFunction);

function listeningFunction()
{
    /*Beacuse it is the server side the console .log will appear on the command line 
    not our browser*/
    console.log('Server is running');
    console.log('Port Number is '+port);
}

app.post('/addNewData', addMyNewData)

function addMyNewData(request, response) {
    projectData = request.body;
    console.log("Data POST");
    /*to make sure the server recognize POST*/
    console.log(projectData);
}
/*To make the GEt request and send the data to the client-side to/allData*/
app.get('/allData', sendMyData);

function sendMyData(request,response)
{
    response.send(projectData);
    console.log("Data GET");
    /*To make sure the server recognize GET*/
    console.log(projectData);
}


